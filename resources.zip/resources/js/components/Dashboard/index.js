import React, {useEffect} from 'react'
import {useHistory} from 'react-router-dom'
// import './Dashboard.css'
import logo from './../Images/6.png'

const Dashboard = () => {

    useEffect(() => {
        if(!localStorage.getItem('user_info'))
        {
            history.push('/sign-up');
        }
    }, [])

    const history = useHistory();

    return (
        <>
            {/* <div className='sidebar'>
                <a href='/'>
                <div className='sidebar-brand'>
                    <h2><span className='las la-globe-asia'></span>YOJANA</h2>
                </div>
                </a>
                <div className='sidebar-menu'>
                    <ul>
                        <li><a href='' className='active'><span className='las la-stream'>
                                       </span>DashBoard<span></span>
                        </a></li>
                        <li><a href=''><span className='las la-user'>
                                       </span>My Profile<span></span>
                        </a></li>
                        <li><a href=''><span className='las la-sign-out-alt'>
                                       </span>Logout<span></span>
                        </a></li>
                    </ul>
                </div>
            </div>

            <div className='main-content'>
                <header>
                    <div className='header-title'>
                        <h2>
                            <lable for=''>
                                <span className='las la-bars'></span>
                            </lable>
                            Dashboard
                        </h2>
                        <div className='user-wrapper'>
                            <img src={logo} alt='img' width='40px' height='40px'/>
                            <div>
                                <h4>Vijay Borge</h4>
                                <small>Super admin</small>
                            </div>
                        </div>
                    </div>
                </header>

                <main>
                    <div className='complete-profile'>
                        <div className='warning'>
                            Please complete your profile to get more applicable schemes.
                            <span className='las la-times'></span>
                        </div>
                    </div>
                    <div className='cards'>
                        <div className='card-single'>
                            <div>
                                <h1>54</h1>
                                <span>Available Schemes</span>
                            </div>
                            <div>
                                <span className='las la-list'></span>
                            </div>
                        </div>
                        <div className='card-single'>
                            <div>
                                <h1>0</h1>
                                <span>Applicable Schemes</span>
                            </div>
                            <div>
                                <span className='las la-clipboard-list'></span>
                            </div>
                        </div>
                        <div className='card-single'>
                            <div>
                                <h1>0</h1>
                                <span>Applied Schemes</span>
                            </div>
                            <div>
                                <span className='las la-list-alt'></span>
                            </div>
                        </div>
                    </div>
                </main>
            </div> */}
            <h1>Dashboard</h1>
        </>
    )
}

export default Dashboard
